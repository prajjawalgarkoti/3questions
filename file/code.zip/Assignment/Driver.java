package Assignment;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Driver {
	public static void main(String[] args) {
	List <Employee> employees=new ArrayList<Employee>();
	        Employee e1=new Employee(1,"xyz",21);
			Employee e2=new Employee(8,"mno",27);
			Employee e3=new Employee(9,"abc",20);
			Employee e4=new Employee(5,"hey",30);
			Employee e5=new Employee(4,"hello",28);
			Employee e6=new Employee(2,"yeah",22);
			employees.add(e1);
			employees.add(e2);
			employees.add(e3);
			employees.add(e4);
			employees.add(e5);
			employees.add(e6);
		
		
		int youngeremployee = employees.stream().map(Employee::getAge).min(Integer::compare).get();
		System.out.println("Youngest Employee" +youngeremployee);
		employees.stream().filter(emp->emp.getAge()==youngeremployee).forEach(System.out::println);
		
		int Elderemployee = employees.stream().map(Employee::getAge).max(Integer::compare).get();
		System.out.println("Elder Employee" +Elderemployee);
		employees.stream().filter(emp->emp.getAge()==Elderemployee).forEach(System.out::println);
	}
	

}
