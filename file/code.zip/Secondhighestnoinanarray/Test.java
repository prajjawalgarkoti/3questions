package Secondhighestnoinanarray;

import java.util.Arrays;  
public class Test{  
public static int SecondLargestno(int[] a, int total){  
Arrays.sort(a);  
return a[total-2];  
}  
public static void main(String args[]){  
int a[]={5,25,47,5,8,9};  
int b[]={76,54,75,72,47,85,24};  
System.out.println("Second Largest: "+SecondLargestno(a,6));  
System.out.println("Second Largest: "+SecondLargestno(b,7));  
}}  